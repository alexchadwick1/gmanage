# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2015 Alexa Chadwick <alexchadwick1@outlook.com>
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

from locale import gettext as _

from gi.repository import Gtk, Vte # pylint: disable=E0611
from gi.repository import GLib
import logging
logger = logging.getLogger('gmanage3')

from gmanage3_lib import Window
from gmanage3.AboutGmanage3Dialog import AboutGmanage3Dialog
from gmanage3.PreferencesGmanage3Dialog import PreferencesGmanage3Dialog

from multiprocessing import Process
import subprocess
import os
import subprocess as sub
from subprocess import Popen
import grp,pwd,os
from os.path import expanduser
from subprocess import Popen, PIPE



# See gmanage3_lib.Window.py for more details about how this class works
class Gmanage3Window(Window):
    __gtype_name__ = "Gmanage3Window"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(Gmanage3Window, self).finish_initializing(builder)

        self.AboutDialog = AboutGmanage3Dialog
        self.PreferencesDialog = PreferencesGmanage3Dialog

        # Code for other initialization actions should be added here.
    os.system("/usr/bin/cmds.gm3 37.gmanage")
    os.system("/usr/bin/cmds.gm3 38.gmanage &")
    os.system("/usr/bin/cmds.gm3 39.gmanage &")
#Users
    def on_USRPASSWD_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 34.gmanage")
    def on_USRLS_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 33.gmanage")
    def on_SUSRLS_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 28.gmanage")
    def on_ADDUSR_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 03.gmanage")
    def on_DELUSR_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 08.gmanage")
    def on_ALLUSRPASSWD_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 04.gmanage")
    def on_ACTNME_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 02.gmanage")
    def on_STPSWD_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 40.gmanage")
#Processes
    def on_RNPROC_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 22.gmanage")
    def on_PROCTREE_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 16.gmanage")
    def on_KILLPROC_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 12.gmanage")
    def on_OPORTS_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 15.gmanage")
#Packages
    def on_LSPKG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 13.gmanage")
    def on_IPKG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 11.gmanage")
    def on_UPKG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 31.gmanage")
    def on_SPKG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 27.gmanage")
    def on_UPDATE_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 30.gmanage")
#Backup
    def on_SYSBKP_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 29.gmanage")
    def on_RSBKP_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 23.gmanage")
    def on_MVBKP_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 14.gmanage")
#Remote
    def on_RMAC_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 19.gmanage")
    def on_RMRBT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 21.gmanage")
    def on_RMBKP_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 20.gmanage")
#Utilities
    def on_VDT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 35.gmanage")
    def on_SDT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 24.gmanage")
    def on_UPT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 32.gmanage")
    def on_PST_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 17.gmanage")
    def on_PWALL_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 18.gmanage")
    def on_SHMY_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 25.gmanage")
#Other
    def on_DCT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 07.gmanage")
    def on_IBG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 10.gmanage")
    def on_DCPSH_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 06.gmanage")
    def on_SOP_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 26.gmanage")
#Help
    def on_HOME_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 09.gmanage")
    def on_ABOUT_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 01.gmanage")
    def on_BUG_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 05.gmanage")
    def on_UPD_clicked(self, button):
        os.system("/usr/bin/cmds.gm3 update.gmanage")



